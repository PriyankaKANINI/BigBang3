﻿//using System.ComponentModel.DataAnnotations;

//namespace Tour_Images.Models
//{
//    public class Tour
//    {
//        [Key]
//        public int TourId { get; set; }
//        public string? Name { get; set; }

//        // Collection of TourImages related to this Tour
//        public ICollection<TourImage> TourImages { get; set; }
//    }
//}
